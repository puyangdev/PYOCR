//
//  AppDelegate.h
//  PYOCR
//
//  Created by PodiMac on 2017/4/10.
//  Copyright © 2017年 于浦洋. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

